//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#import <JPUSHService.h>

#ifdef NSFoundationVersionNumber_iOS_9_x_Max
#import <UserNotifications/UserNotifications.h>
#endif
