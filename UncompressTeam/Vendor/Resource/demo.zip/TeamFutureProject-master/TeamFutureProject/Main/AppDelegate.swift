//
//  HomeViewController.swift
//  TeamFutureProject
//
//  Created by Mac on 2019/8/26.
//  Copyright © 2019 ghostlord. All rights reserved.
//


import UIKit
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {

        self.window = UIWindow.init(frame: UIScreen.main.bounds)
        let rootVC = MainViewController()
        self.window?.rootViewController = rootVC
        self.window?.makeKeyAndVisible()

        return true
    }
}
//
//
//import UIKit
//import BDLibWorkingSwift
//@UIApplicationMain
//class AppDelegate: BNAppDelegate {
//
//    override func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
//        self.BN_AppName = "MGQH_iOS"
//        self.BN_AppHost = "http://api.futures104.xyz"
//        self.regiestJPush(key: "484b45fbd069973650a2462e", launchOptions: launchOptions)
//        self.initBlock = {
//            self.window = UIWindow.init(frame: UIScreen.main.bounds)
//            let rootVC = MainViewController()
//            self.window?.rootViewController = rootVC
//            self.window?.makeKeyAndVisible()
//        }
//        return super.application(application, didFinishLaunchingWithOptions:launchOptions)
//    }
//
//}
