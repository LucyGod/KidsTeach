//
//  MainViewController.swift
//  TeamFutureProject
//
//  Created by Mac on 2019/8/26.
//  Copyright © 2019 ghostlord. All rights reserved.
//

import UIKit
import SwifterSwift
class MainViewController: BaseTabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // 初始化
        p_initialize()
        
        // 设置子控制器
        p_setUpChildVC()
        
    }
    
    func p_initialize(){
        
        self.tabBar.barTintColor = UIColor.white
        
        self.tabBar.tintColor = ColorTheme
    }
    
    func p_setUpChildVC(){
        
        p_addChildrenController(viewController: HomeViewController.init(), title: "首页", image: UIImage(named: "tab_home_nor")?.original, selectedImage: UIImage(named: "tab_home_sel")?.original)
        p_addChildrenController(viewController: MarketViewController.init(), title: "行情", image: UIImage(named: "tab_hq_nor")?.original, selectedImage: UIImage(named: "tab_hq_sel")?.original)
        p_addChildrenController(viewController: CommunityViewController.init(), title: "话题", image: UIImage(named: "tab_community_nor")?.original, selectedImage: UIImage(named: "tab_community_sel")?.original)
        p_addChildrenController(viewController: MeViewController.init(), title: "我的", image: UIImage(named: "tab_me_nor")?.original, selectedImage: UIImage(named: "tab_me_sel")?.original)
    }
    
    func p_addChildrenController(viewController: UIViewController, title: String, image: UIImage?, selectedImage: UIImage?) {
        
        viewController.tabBarItem.image = image
        viewController.tabBarItem.selectedImage = selectedImage
        viewController.title = title
        
        let nav = BaseNavigationController.init(rootViewController: viewController)
        self.addChild(nav)
    }
}
