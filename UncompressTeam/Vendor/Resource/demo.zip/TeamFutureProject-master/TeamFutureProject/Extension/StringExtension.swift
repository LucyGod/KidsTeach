//
//  StringExtension.swift
//  GeneralProject
//
//  Created by Mac on 2019/7/23.
//  Copyright © 2019 ghostlord. All rights reserved.
//

import UIKit
import CommonCrypto

// MARK: - 字符串常用扩展
extension String {
    
    /// 是否是空字符串
    ///
    /// - Parameter string: 需要检测的字符串
    /// - Returns: 空返回true
    public static func gl_empty(string: Any?) -> Bool {
        
        var empty = true
        
        if string != nil {
            
            if let stringValue = string as? String {
                
                let newStringVaule = self.gl_removeHeadAndTailSpaceAndNewlines(string: stringValue)
                
                if newStringVaule.count > 0 {
                    empty = false
                }
                
            }else if let nstringValue = string as? NSString {
                
                let newStringVaule = self.gl_removeHeadAndTailSpaceAndNewlines(nsstring: nstringValue)
                
                if newStringVaule.length > 0 {
                    empty = false
                }
            }
        }
        
        return empty
    }
    
    /// 去掉首尾空格和换行符(String)
    ///
    /// - Parameter string: 需要操作的字符串
    /// - Returns: 去掉后的字符串
    public static func gl_removeHeadAndTailSpaceAndNewlines(string: String!) -> String {
        
        let whiteSpaceAndNewlines = CharacterSet.whitespacesAndNewlines
        
        return string.trimmingCharacters(in: whiteSpaceAndNewlines)
    }
    
    /// 去掉首尾空格和换行符(NSString)
    ///
    /// - Parameter nsstring: 需要操作的字符串
    /// - Returns: 去掉后的字符串
    public static func gl_removeHeadAndTailSpaceAndNewlines(nsstring: NSString!) -> NSString {
        
        let whiteSpaceAndNewlines = NSCharacterSet.whitespacesAndNewlines
        
        return nsstring.trimmingCharacters(in: whiteSpaceAndNewlines) as NSString
    }
    
    
    /// 计算字体所占区域高度
    ///
    /// - Parameters:
    ///   - font: 字体
    ///   - width: 宽度限制
    /// - Returns: 占据的高度
    public func gl_heightForString(font: UIFont, width: CGFloat) -> CGFloat {
        
        let nsstr: NSString = NSString.init(string: self)
        
        let rect = nsstr.boundingRect(with: CGSize.init(width: width, height: CGFloat(MAXFLOAT)), options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil)
        return ceil(rect.size.height)
    }
    
    /// 计算字符串的md5
    ///
    /// - Returns: 字符串计算的md5
    public func gl_md5() -> String {
        
        if !String.gl_empty(string: self) {
            let tempStr = self.cString(using: String.Encoding.utf8)
            let strLen = CUnsignedInt(self.lengthOfBytes(using: String.Encoding.utf8))
            let digestLen = Int(CC_MD5_DIGEST_LENGTH)
            let result = UnsafeMutablePointer<CUnsignedChar>.allocate(capacity: digestLen)
            CC_MD5(tempStr!, strLen, result)
            let hash = NSMutableString()
            for i in 0 ..< digestLen {
                hash.appendFormat("%02x", result[i])
            }
            result.deallocate()
            return String(format: hash as String)
        }else {
            return ""
        }
    }
    
}
