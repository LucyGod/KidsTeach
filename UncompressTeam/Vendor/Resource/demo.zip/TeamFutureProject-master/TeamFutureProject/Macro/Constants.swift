//
//  Constants.swift
//  GeneralProject
//
//  Created by Mac on 2019/6/12.
//  Copyright © 2019 ghostlord. All rights reserved.
//

import UIKit

// ----------- 公共尺寸 ------
/* 屏幕宽 */
public let SCREEN_WIDTH: CGFloat =  CGFloat(UIScreen.main.bounds.width)
/* 屏幕高 */
public let SCREEN_HEIGHT: CGFloat =  CGFloat(UIScreen.main.bounds.height)
/* 较短的宽度为(竖屏为宽，横屏为高) */
public let SCREEN_SHORT: CGFloat = (SCREEN_WIDTH < SCREEN_HEIGHT ? SCREEN_WIDTH : SCREEN_HEIGHT)

// --------- 适配公共宏 ------
/** 是否是异形屏 */
public let IS_HETERO_SCREEN:Bool =  (GL_iPhone_X || GL_iPhone_X_Max)

/** 是否是竖屏 */
public let IS_PORTRAIT:Bool =  (UIApplication.shared.statusBarOrientation == UIInterfaceOrientation.portrait || UIApplication.shared.statusBarOrientation == UIInterfaceOrientation.portraitUpsideDown)

// -- 导航栏和Tabbar针对iPhone X 的适配  --
public let Nav_topH: CGFloat           =   (IS_HETERO_SCREEN ? 88.0 : 64.0)         // 导航栏+状态栏高度
public let Tab_H: CGFloat              =   (IS_HETERO_SCREEN ? 83.0 : 49.0)         // 标签栏高度
public let NavMustAdd: CGFloat         =   (IS_HETERO_SCREEN ? 34.0 : 0.0)          // 异形屏上方安全高度
public let TabMustAdd: CGFloat         =   (IS_HETERO_SCREEN ? 20.0 : 0.0)          // 异形屏下方安全高度
public let Status_H: CGFloat           =   (IS_HETERO_SCREEN ? 44.0 : 20.0)         // 状态栏高度
public let NavigationItem_H: CGFloat   =   (44.0)   // 导航栏高度
public let Statue_Height: CGFloat      =   UIApplication.shared.statusBarFrame.size.height  // 状态栏高度
public let NavBar_height: CGFloat      =   (Statue_Height + 44.0)                   // 导航栏+状态栏高度

// 手机尺寸型号
public let GL_iPhone_4x: Bool      =   (SCREEN_WIDTH == 320 && SCREEN_HEIGHT == 480)
public let GL_iPhone_5x: Bool      =   (SCREEN_WIDTH == 320 && SCREEN_HEIGHT == 568)
public let GL_iPhone_6x: Bool      =   (SCREEN_WIDTH == 375 && SCREEN_HEIGHT == 667)
public let GL_iPhone_plus: Bool    =   (SCREEN_WIDTH == 414 && SCREEN_HEIGHT == 736)
public let GL_iPhone_X: Bool       =   (SCREEN_WIDTH == 375 && SCREEN_HEIGHT == 812)   // iPhone X,    iPhone XS
public let GL_iPhone_X_Max: Bool   =   (SCREEN_WIDTH == 414 && SCREEN_HEIGHT == 896)   // iPhone XR,   iPhone XS Max

// 颜色相关
public let ColorBackGround: UIColor    =   UIColor.gl_hex(hex: 0xffffff, alpha: 1.0)    // 页面背景
public let ColorTheme: UIColor         =   UIColor.gl_hex(hex: 0x108ee9, alpha: 1.0)    // 主题色
public let ColorTitle: UIColor         =   UIColor.gl_hex(hex: 0x333333, alpha: 1.0)    // 标题颜色
public let ColorNomalTitle: UIColor    =   UIColor.gl_hex(hex: 0x999999, alpha: 1.0)    // 正文颜色
public let ColorTipTitle: UIColor      =   UIColor.gl_hex(hex: 0xcccccc, alpha: 1.0)    // 提示文字
public let ColorDarkRed: UIColor       =   UIColor.gl_hex(hex: 0xD75558, alpha: 1.0)    // 暗红色
public let ColorDarkGreen: UIColor     =   UIColor.gl_hex(hex: 0x41A064, alpha: 1.0)    // 暗绿色
public let ColorBlue: UIColor          =   UIColor.gl_hex(hex: 0x108ee9, alpha: 1.0)    // 蓝色
public let ColorSepLine: UIColor       =   UIColor.gl_hex(hex: 0xeeeeee, alpha: 1.0)    // 分割线颜色
public let ColorSepRect: UIColor       =   UIColor.gl_hex(hex: 0xf5f5f5, alpha: 1.0)    // 分割色块颜色

// 字体样式
public let FontTitleName = "DIN Alternate"      // 标题字体名称
public let FontNomalName = "Farah"              // 正常字体名称

// 按比例适配宽度
public func SCALEWIDTH(width: CGFloat) -> CGFloat {
    
    return SCREEN_WIDTH / 375.0 * width    
}

// MARK: - 16进制颜色
extension UIColor {
    
    public class func gl_hex(hex: Int , alpha: CGFloat = 1.0) -> UIColor {
        
        return self.init(red: CGFloat((hex & 0xff0000) >> 16) / 255.0, green: CGFloat(((hex & 0xFF00) >> 8)) / 255.0, blue: CGFloat((hex & 0xFF)) / 255.0, alpha: alpha)
    }
}
