
//
//  BaseViewController.swift
//  GeneralProject
//
//  Created by Mac on 2019/8/12.
//  Copyright © 2019 ghostlord. All rights reserved.
//

import UIKit

open class BaseViewController: UIViewController {
    
    /// 自定义返回按钮
    lazy var customBackBtn: UIBarButtonItem = {
        let backBtn = UIBarButtonItem.init()
        backBtn.title = ""
        return backBtn
    }()
    
    open override func viewDidLoad() {
        super.viewDidLoad()
        
        gl_customInitialize()
    }
    
    /// 标题的属性设置
    open var titleTextAttributes: [NSAttributedString.Key: Any]? = [:] {
        
        didSet{
            
            if self.titleTextAttributes != nil {
                self.navigationController?.navigationBar.titleTextAttributes = self.titleTextAttributes
            }
            
        }
        
    }
    
    /// 自定义初始化
    open func gl_customInitialize() {
        self.view.backgroundColor = .white
        self.navigationItem.backBarButtonItem = self.customBackBtn
        self.navigationController?.navigationBar.tintColor = UIColor.black
        
        if self.titleTextAttributes != nil {
            self.navigationController?.navigationBar.titleTextAttributes = self.titleTextAttributes
        }
    }
    
}
