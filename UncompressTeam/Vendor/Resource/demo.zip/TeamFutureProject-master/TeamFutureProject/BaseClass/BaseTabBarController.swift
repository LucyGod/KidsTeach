//
//  BaseView.swift
//  GeneralProject
//
//  Created by Mac on 2019/8/12.
//  Copyright © 2019 ghostlord. All rights reserved.
//

import UIKit

class BaseTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        gl_customInitialize()
    }
    
    /// 自定义初始化
    open func gl_customInitialize() {
        self.view.backgroundColor = .white
        
    }

}
