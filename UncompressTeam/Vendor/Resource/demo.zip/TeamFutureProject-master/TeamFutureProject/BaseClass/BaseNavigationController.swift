//
//  BaseNavigationController.swift
//  GeneralProject
//
//  Created by Mac on 2019/8/12.
//  Copyright © 2019 ghostlord. All rights reserved.
//

import UIKit

open class BaseNavigationController: UINavigationController {
    
    /// 导航栏背景颜色
    open var navBarBackGroundColor: UIColor? {
        
        didSet{
            
            if self.navBarBackGroundColor != nil {
                
                self.navigationBar.setBackgroundImage(UIImage.gl_image(color: self.navBarBackGroundColor!, size: CGSize.init(width: 88, height: UIScreen.main.bounds.size.width)), for: UIBarMetrics.default)
                
            }
        }
    }
    
    open override func viewDidLoad() {
        super.viewDidLoad()
        
        gl_customInitialize()
        // 设置
        self.navBarBackGroundColor = .white
    }
    
    /// 自定义初始化
    open func gl_customInitialize() {
        self.view.backgroundColor = .white
        
        if self.navBarBackGroundColor != nil  {
            self.navigationBar.setBackgroundImage(UIImage.gl_image(color: self.navBarBackGroundColor!, size: CGSize.init(width: 88, height: UIScreen.main.bounds.size.width)), for: UIBarMetrics.default)
        }
        
    }
}


// MARK: - UIImage Extension
public extension UIImage {
    
    /// SwifterSwift: Create UIImage from color and size.
    ///
    /// - Parameters:
    ///   - color: image fill color.
    ///   - size: image size.
    class func gl_image(color: UIColor, size: CGSize) -> UIImage! {
        UIGraphicsBeginImageContextWithOptions(size, false, 1)
        
        defer {
            UIGraphicsEndImageContext()
        }
        
        color.setFill()
        UIRectFill(CGRect(origin: .zero, size: size))
        
        guard let aCgImage = UIGraphicsGetImageFromCurrentImageContext()?.cgImage else {
            
            return UIImage.init()
        }
        return UIImage.init(cgImage: aCgImage)
    }
}
