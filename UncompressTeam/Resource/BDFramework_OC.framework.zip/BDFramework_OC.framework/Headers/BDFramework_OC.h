//
//  BDFramework_OC.h
//  BDFramework-OC
//
//  Created by Bingo on 2019/8/6.
//  Copyright © 2019 Bingo. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BDFramework_OC.
FOUNDATION_EXPORT double BDFramework_OCVersionNumber;

//! Project version string for BDFramework_OC.
FOUNDATION_EXPORT const unsigned char BDFramework_OCVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BDFramework_OC/PublicHeader.h>


